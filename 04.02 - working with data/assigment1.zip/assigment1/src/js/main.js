import { contacts } from '../data/contacts.js';

console.log(contacts);
